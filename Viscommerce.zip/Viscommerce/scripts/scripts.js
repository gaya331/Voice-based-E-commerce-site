function readText(text) {
    fetch(`/speak/${encodeURIComponent(text)}`)
        .then(response => {
            if (response.status !== 204) {
                console.error('Error speaking text');
            }
        });
}

document.addEventListener('keydown', (event) => {
    if (event.key === 'Tab') {
        const focusedElement = document.activeElement;
        if (focusedElement) {
            const text = focusedElement.getAttribute('data-voice') || 'Unknown element';
            readText(text);
        }
    }
});
